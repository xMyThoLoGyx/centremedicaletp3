<?php
$map = array (
		1 => array('001_initialize_i18n_schema' => 'I18nMigration001')
);
?>
